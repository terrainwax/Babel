//
// Created by entropy on 9/28/18.
//

#include "CryptoException.h"

CryptoException::CryptoException(const BabelString &message)
    : BabelException(message)
{

}
