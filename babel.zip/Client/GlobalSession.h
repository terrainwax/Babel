//
// Created by terrainwax on 03/10/2018.
//

#ifndef CPP_BABEL_2018_GLOBALSESSION_H
#define CPP_BABEL_2018_GLOBALSESSION_H

#include "client.h"

extern Client *client;

#endif //CPP_BABEL_2018_GLOBALSESSION_H
