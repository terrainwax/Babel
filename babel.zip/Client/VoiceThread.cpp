//
// Created by terrainwax on 07/10/2018.
//

#include "VoiceThread.h"
#include "Voice.h"
#include "GlobalSession.h"

void VoiceThread::run() {
    while (true) {

    }
}