//
// Created by entropy on 9/28/18.
//

#include "NetworkException.h"

NetworkException::NetworkException(const BabelString &message)
        : BabelException(message)
{

}
