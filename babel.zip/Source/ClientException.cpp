//
// Created by entropy on 9/28/18.
//

#include "ClientException.h"

ClientException::ClientException(const BabelString &message)
        : BabelException(message)
{

}
