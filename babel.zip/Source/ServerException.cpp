//
// Created by entropy on 9/28/18.
//

#include "ServerException.h"

ServerException::ServerException(const BabelString &message)
        : BabelException(message)
{

}