/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Login
{
public:
    QWidget *centralWidget;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QFrame *frame_2;
    QFrame *frame_3;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *pushButton;
    QLabel *label_5;
    QLabel *label_7;
    QWidget *page_2;
    QLabel *label_6;
    QLabel *label;
    QFrame *line;
    QTextEdit *textEdit;
    QLabel *label_8;
    QPushButton *caltest;

    void setupUi(QMainWindow *Login)
    {
        if (Login->objectName().isEmpty())
            Login->setObjectName(QStringLiteral("Login"));
        Login->setEnabled(true);
        Login->resize(1280, 720);
        Login->setMinimumSize(QSize(1280, 720));
        Login->setMaximumSize(QSize(1280, 720));
        Login->setAutoFillBackground(false);
        centralWidget = new QWidget(Login);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(0, 0, 1280, 720));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        frame_2 = new QFrame(page);
        frame_2->setObjectName(QStringLiteral("frame_2"));
        frame_2->setEnabled(true);
        frame_2->setGeometry(QRect(0, 0, 1280, 720));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        frame_3 = new QFrame(frame_2);
        frame_3->setObjectName(QStringLiteral("frame_3"));
        frame_3->setGeometry(QRect(425, 185, 430, 350));
        frame_3->setAutoFillBackground(false);
        frame_3->setStyleSheet(QLatin1String(".QFrame{\n"
"background-color: rgb(40, 40, 40);\n"
"border-radius: 10px;\n"
"}"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        label_2 = new QLabel(frame_3);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(115, 20, 201, 41));
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/Ressources/Images/babel.png")));
        label_2->setScaledContents(true);
        lineEdit = new QLineEdit(frame_3);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(70, 130, 281, 41));
        QFont font;
        font.setPointSize(14);
        lineEdit->setFont(font);
        lineEdit->setStyleSheet(QLatin1String(".QLineEdit{\n"
"border:2px solid rgb(18, 18, 18);\n"
"color:rgb(208, 208, 208);\n"
"background:rgb(50, 50, 50)\n"
"}"));
        lineEdit_2 = new QLineEdit(frame_3);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(70, 210, 281, 41));
        lineEdit_2->setFont(font);
        lineEdit_2->setStyleSheet(QLatin1String(".QLineEdit{\n"
"border:2px solid rgb(18, 18, 18);\n"
"color:rgb(208, 208, 208);\n"
"background:rgb(50, 50, 50);\n"
"}"));
        lineEdit_2->setEchoMode(QLineEdit::Password);
        label_3 = new QLabel(frame_3);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(70, 100, 201, 21));
        QFont font1;
        font1.setPointSize(16);
        label_3->setFont(font1);
        label_3->setStyleSheet(QLatin1String(".QLabel{\n"
"color:rgb(138, 138, 138)\n"
"}"));
        label_4 = new QLabel(frame_3);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(70, 180, 201, 21));
        label_4->setFont(font1);
        label_4->setStyleSheet(QLatin1String(".QLabel{\n"
"color:rgb(138, 138, 138)\n"
"}"));
        pushButton = new QPushButton(frame_3);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(70, 270, 281, 41));
        pushButton->setFont(font);
        pushButton->setStyleSheet(QLatin1String(".QPushButton {\n"
"border-radius: 5px;\n"
"background:rgb(152, 0, 0);\n"
"color:rgb(208, 208, 208);\n"
"}\n"
"\n"
".QPushButton:pressed {\n"
"background:rgb(89, 89, 89);\n"
"}"));
        pushButton->setFlat(false);
        label_5 = new QLabel(page);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setEnabled(true);
        label_5->setGeometry(QRect(0, 0, 1280, 720));
        label_5->setPixmap(QPixmap(QString::fromUtf8(":/Ressources/Images/20860.jpg")));
        label_7 = new QLabel(page);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(0, 0, 1280, 720));
        label_7->setStyleSheet(QLatin1String(".QLabel{\n"
"border:none;\n"
"background-color:rgb(62, 62, 62);\n"
"}"));
        stackedWidget->addWidget(page);
        label_7->raise();
        label_5->raise();
        frame_2->raise();
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        label_6 = new QLabel(page_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(0, 0, 1280, 720));
        label_6->setStyleSheet(QLatin1String(".QLabel{\n"
"background-color:rgb(52, 52, 52);\n"
"}"));
        label = new QLabel(page_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 0, 241, 721));
        label->setStyleSheet(QLatin1String(".QLabel{\n"
"background-color:rgb(33, 33, 33);\n"
"}"));
        line = new QFrame(page_2);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(20, 160, 201, 16));
        line->setStyleSheet(QLatin1String(".Line{\n"
"border-color:rgb(117, 117, 117);\n"
"}"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        textEdit = new QTextEdit(page_2);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(260, 670, 1001, 41));
        textEdit->setStyleSheet(QLatin1String(".QTextEdit{\n"
"border:none;\n"
"background-color:rgb(48, 48, 48);\n"
"color:rgb(255, 255, 255);\n"
"}"));
        label_8 = new QLabel(page_2);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(910, -131, 371, 131));
        label_8->setStyleSheet(QLatin1String(".QLabel{\n"
"background-color:rgba(38, 38, 38, 150)\n"
"}"));
        caltest = new QPushButton(page_2);
        caltest->setObjectName(QStringLiteral("caltest"));
        caltest->setGeometry(QRect(50, 670, 93, 28));
        stackedWidget->addWidget(page_2);
        Login->setCentralWidget(centralWidget);

        retranslateUi(Login);

        stackedWidget->setCurrentIndex(1);
        pushButton->setDefault(false);


        QMetaObject::connectSlotsByName(Login);
    } // setupUi

    void retranslateUi(QMainWindow *Login)
    {
        Login->setWindowTitle(QApplication::translate("Login", "Login", nullptr));
        label_2->setText(QString());
        label_3->setText(QApplication::translate("Login", "Nom d'utilisateur", nullptr));
        label_4->setText(QApplication::translate("Login", "Mot de passe", nullptr));
        pushButton->setText(QApplication::translate("Login", "Se connecter", nullptr));
        label_5->setText(QString());
        label_7->setText(QString());
        label_6->setText(QString());
        label->setText(QString());
        label_8->setText(QString());
        caltest->setText(QApplication::translate("Login", "call test", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Login: public Ui_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
